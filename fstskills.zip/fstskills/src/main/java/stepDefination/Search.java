package stepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Search {
	//System.setproperty("webdriver.chrome.driver","C:\\Users\\Munagala\\eclipse-workspace\\fstskills\\target\\chromedriver.exe");
	WebDriver wd;
	
	@Given("Open the Chrome browser and launch the google")
	public void open_the_chrome_browser_and_launch_the_google() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new io.cucumber.java.PendingException();
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Munagala\\eclipse-workspace\\fstskills\\target\\chromedriver.exe");
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.google.com/");
		Thread.sleep(5000);
		System.out.println("Chrome browser is opened");
		System.out.println("URL:"+wd.getCurrentUrl());
	}

	@When("i enter something")
	public void i_enter_something() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		wd.findElement(By.name("q")).sendKeys("Automation");
		Thread.sleep(5000);
		wd.findElement(By.name("btnK")).click();
		System.out.println("entered 'Automation' on search box and click on enter");
		
	}

	@Then("should display the results")
	public void should_display_the_results() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new io.cucumber.java.PendingException();
		System.out.println("results are displayed");
		Thread.sleep(2000);
		wd.findElement(By.xpath("//*[@id=\"rso\"]/div[1]/div/div[1]/div/div[1]/div/div[2]/div/div/div[2]/div/div/div[1]/a/h3")).click();
		System.out.println("Selected first link and navigated to desired page");
		System.out.println("URL:"+wd.getCurrentUrl());
		System.out.println("Title:"+wd.getTitle());
		wd.close();
		
		
	}
	
}
